package com.github.davidmoten.geo;

/**
 * Even or Odd.
 * 
 * @author dave
 * 
 */
public enum Parity {
    EVEN, ODD;
}
